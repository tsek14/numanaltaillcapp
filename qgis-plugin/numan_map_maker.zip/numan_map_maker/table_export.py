# -*- coding: utf-8 -*-
"""Талбайн хүснэгтийг Excel (.xlsx) эсвэл CSV файл руу гаргана."""
import csv
import os

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsCoordinateTransformContext,
    QgsFeature,
    QgsField,
    QgsVectorFileWriter,
    QgsVectorLayer,
)


PCT_HEAD = "Хувь, %"


def _rows(head1, head2, rows, total, decimals, with_total, total_label="Нийт"):
    """[(нэр, утга, хувь)]"""
    def share(v):
        return round(v / total * 100.0, 2) if total > 0 else 0.0
    out = [(label, round(value, decimals), share(value)) for label, value, _c in rows]
    if with_total and len(rows) > 1:
        out.append((total_label, round(total, decimals), 100.0))
    return out


def write_csv(path, head1, head2, rows, total, decimals=2, with_total=True, percent=False,
              total_label="Нийт"):
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow([head1, head2] + ([PCT_HEAD] if percent else []))
        for label, value, pct in _rows(head1, head2, rows, total, decimals, with_total,
                                       total_label):
            w.writerow([label, f"{value:.{decimals}f}"] + ([f"{pct:.2f}"] if percent else []))
    return path


def write_xlsx(path, head1, head2, rows, total, decimals=2, with_total=True, percent=False,
               total_label="Нийт"):
    """GDAL-ийн XLSX драйвераар бичнэ. Амжилтгүй бол алдааны бичвэр буцаана ('' = амжилттай)."""
    lyr = QgsVectorLayer("None", "Талбай", "memory")
    pr = lyr.dataProvider()
    fields = [QgsField(head1 or "Ангилал", QVariant.String),
              QgsField(head2 or "Талбай", QVariant.Double, "double", 20, decimals)]
    if percent:
        fields.append(QgsField(PCT_HEAD, QVariant.Double, "double", 10, 2))
    pr.addAttributes(fields)
    lyr.updateFields()
    feats = []
    for label, value, pct in _rows(head1, head2, rows, total, decimals, with_total,
                                   total_label):
        f = QgsFeature(lyr.fields())
        f.setAttributes([label, float(value)] + ([float(pct)] if percent else []))
        feats.append(f)
    pr.addFeatures(feats)
    if os.path.exists(path):
        os.remove(path)
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "XLSX"
    opts.fileEncoding = "UTF-8"
    opts.layerName = "Талбай"
    res = QgsVectorFileWriter.writeAsVectorFormatV3(
        lyr, path, QgsCoordinateTransformContext(), opts)
    err, msg = res[0], res[1]
    if err != QgsVectorFileWriter.NoError:
        return msg or "XLSX бичих боломжгүй"
    return ""


def write(path, head1, head2, rows, total, decimals=2, with_total=True, percent=False,
          total_label="Нийт"):
    """Өргөтгөлөөр нь xlsx эсвэл csv бичнэ. Бодитоор бичсэн файлын зам буцаана.

    XLSX драйвер энэ QGIS-д байхгүй бол ижил нэртэй CSV бичнэ.
    """
    if path.lower().endswith(".xlsx"):
        err = write_xlsx(path, head1, head2, rows, total, decimals, with_total, percent,
                         total_label)
        if not err:
            return path
        path = os.path.splitext(path)[0] + ".csv"
    return write_csv(path, head1, head2, rows, total, decimals, with_total, percent,
                     total_label)


def write_rows(path, head, rows, sheet="Хүснэгт", note=""):
    """Дурын бичвэрийн хүснэгтийг xlsx (боломжгүй бол csv) болгон бичнэ.

    note — доод мөрөнд бичих тайлбар (жишээ нь проекц). Бичсэн файлын замыг буцаана.
    """
    if path.lower().endswith(".xlsx"):
        lyr = QgsVectorLayer("None", sheet, "memory")
        pr = lyr.dataProvider()
        names, used = [], set()
        for h in head:
            n = h or "_"
            while n in used:
                n += "_"
            used.add(n)
            names.append(n)
        pr.addAttributes([QgsField(n, QVariant.String) for n in names])
        lyr.updateFields()
        feats = []
        for r in rows + ([[note] + [""] * (len(head) - 1)] if note else []):
            f = QgsFeature(lyr.fields())
            f.setAttributes([str(v) for v in r])
            feats.append(f)
        pr.addFeatures(feats)
        if os.path.exists(path):
            os.remove(path)
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "XLSX"
        opts.fileEncoding = "UTF-8"
        opts.layerName = sheet
        res = QgsVectorFileWriter.writeAsVectorFormatV3(
            lyr, path, QgsCoordinateTransformContext(), opts)
        if res[0] == QgsVectorFileWriter.NoError:
            return path
        path = os.path.splitext(path)[0] + ".csv"
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(head)
        for r in rows:
            w.writerow(r)
        if note:
            w.writerow([note])
    return path
